//dan id: UJJ36DESJ
//lil sean id: UJSADG01G

module.exports = {
  SLACK_CHANNEL_URL: 'https://hooks.slack.com/services/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',
  MEMBER_ID: '<@UMHJCMHGA>',
  MY_TEAM: 'nya'
};

